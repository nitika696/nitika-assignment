import requests
from bs4 import BeautifulSoup
import json
import pymongo

request = requests.get('https://news.ycombinator.com/')
content= request.content
soup = BeautifulSoup(content, "html.parser")

main_container = soup.find_all('a', {"class": "storylink"})
data = []

for container in main_container:
    item = {}
    item['blog_url'] = container.get("href")

    try:
        open_link = requests.get(item['blog_url'])
        cont = open_link.content
        single_article = BeautifulSoup(cont, 'html.parser')
        if single_article.find('h1') is None:
            item['blog_title'] = container.get_text().strip()
        else:
            item["blog_title"] = single_article.h1.get_text().strip()
        item["blog_desc"] = single_article.p.get_text().strip()[:200]
        item["blog_img_url"] = single_article.img.get("src")
    except Exception as e:
        print(e)
        continue

    data.append(item)
    print("Blog Title : " + item['blog_title'])
    print("Blog Url: " + item['blog_url'])
    print("Blog Description: " + item['blog_desc'])
    print("Blog Image Url: " + item['blog_img_url'])
    print("\n")


with open("savedata.json", "w") as writeJSON:
    json.dump(data, writeJSON, ensure_ascii=False)

uri = "mongodb://127.0.0.1:27017"
client = pymongo.MongoClient(uri)
database = client["blogrecord"]
collection = database["news"]

with open('savedata.json') as f:
    file_data = json.load(f)

collection.insert_many(file_data)
client.close()

show_record = [show_record for show_record in collection.find({})]

print(show_record)

